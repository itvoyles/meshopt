%% runSpringExampleTrust.m
% Example problem taken from Vanderplaats textbook, example 3-1. 
% Unconstrained potential energy minimization of two springs.
options.Display = 'iter';
options.MaxIter = 50;
options.TolFun  = 0.01;
options.TolX    = 0.01;
options.MoveLimit = 0.5;
options.TrustRegion = 'on';
[X,PE]=slp_trust(@fVanderplaatsSpringEx3d1,[5 5],options)